==============================
TYPO3 extension ``adminpanel``
==============================

The Admin Panel displays information about your site in the frontend and
contains a range of metrics including debug and caching information.

:Repository:  https://github.com/typo3/typo3
:Issues:      https://forge.typo3.org/
:Read online: https://docs.typo3.org/c/typo3/cms-adminpanel/10.4/en-us/
:TER:         https://extensions.typo3.org/extension/adminpanel/
