<?php

return [
    'form' => [
        \TYPO3\CMS\Core\ExpressionLanguage\TypoScriptConditionProvider::class,
        \TYPO3\CMS\Form\Domain\Condition\ConditionProvider::class
    ],
];
