===========================
TYPO3 extension ``extbase``
===========================

This is an extension framework to create TYPO3 frontend plugins and TYPO3
backend modules.

:Repository:  https://github.com/typo3/typo3
:Issues:      https://forge.typo3.org/
:Read online: https://docs.typo3.org/
:TER:         https://extensions.typo3.org/extension/extbase/
